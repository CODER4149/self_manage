import imp
from unicodedata import category
from django.contrib import admin
from .models import Category,Item
# Register your models here.
admin.site.register(Category)
admin.site.register(Item)